TL1 Assistant v1.0.0
=========================

QUICK START:
-----------
1. Run the installer for your platform:
   - Linux/macOS: ./scripts/install.sh
   - Windows: scripts\install.bat

2. Or manually start:
   - Linux/macOS: ./start-webgui.sh
   - Windows: Start-WebGUI.cmd

3. Open your browser to: http://localhost:8080

WHAT'S INCLUDED:
---------------
• tl1_web_gui.py - Main application (766 lines)
• data/commands.json - 630+ TL1 commands database
• scripts/ - Installation scripts for all platforms
• docs/ - Comprehensive documentation

SYSTEM REQUIREMENTS:
-------------------
• Python 3.6 or higher
• Flask library (pip install flask)
• Modern web browser
• Network access to TL1 devices

DOCUMENTATION:
-------------
• docs/README.md - Complete project overview
• docs/quick_start.md - Getting started guide
• docs/tap-001.md - Troubleshooting procedures
• docs/tl1_syntax.md - TL1 command reference

For detailed installation and usage instructions, see docs/quick_start.md

Visit the project repository for updates and support.

Build Date: 2025-10-07
Version: 1.0.0
