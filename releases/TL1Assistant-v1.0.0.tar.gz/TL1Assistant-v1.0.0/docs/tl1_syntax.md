# TL1 Command Syntax Reference

Complete reference for TL1 (Transaction Language 1) command syntax used with 1603 SM and 1603 SMX network elements.

## Basic TL1 Command Structure

```
VERB-MODIFIER:[TID]:[AID]:[CTAG]::[PARAMETERS];
```

### Components Breakdown

| Component | Description | Required | Example |
|-----------|-------------|----------|---------|
| **VERB** | Action to perform | Yes | RTRV, ENT, DLT, ED, OPR, RLS |
| **MODIFIER** | Object or resource type | Yes | USER, HDR, ALM-ALL, OC12, T1 |
| **TID** | Target Identifier (Network Element ID) | Yes | NE01, SITE1, NODE_A |
| **AID** | Access Identifier (Specific resource) | Optional | OC12-1-1, T1-1-2-3, ALL |
| **CTAG** | Correlation Tag (Command sequence) | Yes | 1, 100, 999 |
| **PARAMETERS** | Command-specific parameters | Optional | PID=password, MONVAL=15MIN |

## Command Verbs

### Primary Verbs

| Verb | Purpose | Risk Level | Example |
|------|---------|------------|---------|
| **RTRV** | Retrieve information | 🟢 Safe | `RTRV-HDR:NE01::1::;` |
| **ENT** | Enter/Create new resource | 🟡 Medium | `ENT-OC12:NE01:OC12-1-1:2::;` |
| **DLT** | Delete existing resource | 🔴 High | `DLT-OC12:NE01:OC12-1-1:3::;` |
| **ED** | Edit existing resource | 🟡 Medium | `ED-OC12:NE01:OC12-1-1:4::STATE=OOS;` |
| **OPR** | Operate/Start function | 🟡 Medium | `OPR-LPBK-T1:NE01:T1-1-1:5::;` |
| **RLS** | Release/Stop function | 🟢 Safe | `RLS-LPBK-T1:NE01:T1-1-1:6::;` |
| **ACT** | Activate | 🟡 Medium | `ACT-USER:NE01:ADMIN:7::PASSWORD;` |
| **CANC** | Cancel | 🟢 Safe | `CANC-USER:NE01:ADMIN:8::;` |
| **SET** | Set parameters | 🟡 Medium | `SET-ATTR-T1:NE01:T1-1-1:9::TXLEVEL=-15;` |
| **ALW** | Allow/Enable | 🟡 Medium | `ALW-MSG-ALL:NE01::10::;` |
| **INH** | Inhibit/Disable | 🟡 Medium | `INH-MSG-ALL:NE01::11::;` |

### Administrative Verbs

| Verb | Purpose | Example |
|------|---------|---------|
| **CPY** | Copy data | `CPY-MEM:NE01::12::;` |
| **RST** | Reset/Restore | `RST-OC12:NE01:OC12-1-1:13::;` |
| **INIT** | Initialize | `INIT-REG-T3:NE01:T3-1:14::;` |
| **SW** | Switch | `SW-WKG:NE01:OC12-1-1:15::;` |

## Common Modifiers

### Interface Types

| Modifier | Description | Platforms |
|----------|-------------|-----------|
| **OC12** | OC-12 Optical Carrier | SM, SMX |
| **OC48** | OC-48 Optical Carrier | SM, SMX |
| **STS12C** | STS-12 Concatenated | SMX only |
| **T1** | T1 Digital Signal | SM, SMX |
| **T3** | T3 Digital Signal | SM, SMX |
| **POSPORT** | Packet over SONET | SMX only |
| **VCL** | Virtual Channel Link | SM, SMX |
| **VPL** | Virtual Path Link | SM, SMX |
| **ATMPORT** | ATM Port | SM, SMX |

### System Objects

| Modifier | Description | Example Command |
|----------|-------------|-----------------|
| **HDR** | System Header | `RTRV-HDR:NE01::1::;` |
| **ALM-ALL** | All Alarms | `RTRV-ALM-ALL:NE01::2::;` |
| **USER** | User Account | `ACT-USER:NE01:ADMIN:3::PWD;` |
| **EQPT** | Equipment | `RTRV-EQPT:NE01::4::;` |
| **SYNCN** | Synchronization | `RTRV-SYNCN:NE01::5::;` |

## Access Identifier (AID) Patterns

### Hierarchical Addressing

```
SHELF-SLOT-PORT[-SUBPORT]
```

Examples:
- `1-1` (Shelf 1, Slot 1)
- `1-1-1` (Shelf 1, Slot 1, Port 1)
- `1-1-1-1` (Shelf 1, Slot 1, Port 1, Subport 1)

### Interface Specific AIDs

| Interface | AID Format | Example |
|-----------|------------|---------|
| OC12 | `OC12-shelf-slot` | `OC12-1-1` |
| T1 | `T1-shelf-slot-port` | `T1-1-1-1` |
| STS12C | `STS12C-shelf-slot-sts` | `STS12C-1-1-1` |
| VCL | `VCL-shelf-slot-port-vci` | `VCL-1-1-1-100` |

### Special AIDs

| AID | Meaning | Usage |
|-----|---------|--------|
| **ALL** | All instances | `RTRV-ALM-ALL:NE01:ALL:1::;` |
| **(empty)** | Not applicable | `RTRV-HDR:NE01::1::;` |

## Parameter Syntax

### Common Parameters

| Parameter | Format | Description | Example |
|-----------|--------|-------------|---------|
| **STATE** | `STATE=value` | Administrative state | `STATE=IS` |
| **MONVAL** | `MONVAL=value` | Monitoring interval | `MONVAL=15MIN` |
| **PID** | `PID=value` | Password | `PID=secret123` |
| **UID** | `UID=value` | User ID | `UID=OPERATOR` |
| **TXLEVEL** | `TXLEVEL=value` | Transmit level | `TXLEVEL=-10` |

### Parameter Formatting Rules

1. **Multiple Parameters**: Separate with commas
   ```
   ENT-T1:NE01:T1-1-1:1::STATE=IS,TXLEVEL=-15,FRAMING=ESF;
   ```

2. **String Values**: Use quotes for strings with spaces
   ```
   ED-USER:NE01:TECH:1::DESC="Technician Account";
   ```

3. **Boolean Values**: Use standard representations
   ```
   SET-ATTR-OC12:NE01:OC12-1-1:1::LASER=ENABLED;
   ```

## Response Format

### Successful Response
```
TID YYYY-MM-DD HH:MM:SS
M CTAG COMPLD
   [response data]
;
```

### Error Response
```
TID YYYY-MM-DD HH:MM:SS
M CTAG DENY
   ERCD="error_code"
   "Error description"
;
```

### Common Response Codes

| Code | Meaning | Action Required |
|------|---------|-----------------|
| **COMPLD** | Command completed | None |
| **DENY** | Command denied | Check syntax/permissions |
| **PRTL** | Partial completion | Review partial results |
| **REPT** | Autonomous report | Informational |

## Platform-Specific Syntax

### 1603 SM Specific

```bash
# IPAREA commands (SM only)
ENT-IPAREA:NE01:IPAREA-1:1::IPADDR=192.168.1.0,MASK=255.255.255.0;
RTRV-IPAREA:NE01::2::;
DLT-IPAREA:NE01:IPAREA-1:3::;

# Extended VPL operations
ENT-VPL:NE01:VPL-1-1-100:4::STATE=IS;
ED-CRS-VPL:NE01:VPL-1-1-100:5::VPCI=200;
```

### 1603 SMX Specific

```bash
# STS12C commands (SMX only)
ENT-STS12C:NE01:STS12C-1-1-1:1::STATE=IS;
RTRV-PM-STS12C:NE01:STS12C-1-1-1:2::MONVAL=15MIN;

# POSPORT commands (SMX only)
ENT-POSPORT:NE01:POSPORT-1-1:3::STATE=IS;
ED-POSPORT:NE01:POSPORT-1-1:4::SCRAMBLE=ENABLED;

# BLSR commands (SMX only)
ENT-BLSR:NE01:BLSR-1:5::RINGID=1,NODEID=1;
```

## Best Practices

### 1. Command Sequencing
```bash
# Always login first
ACT-USER:NE01:ADMIN:1::PASSWORD;

# Perform operations
RTRV-HDR:NE01::2::;
RTRV-ALM-ALL:NE01::3::;

# Logout when done
CANC-USER:NE01:ADMIN:4::;
```

### 2. Error Handling
- Always check response codes
- Increment CTAG for each command
- Use meaningful TID names
- Validate parameters before sending

### 3. Safety Guidelines
- Test commands on lab equipment first
- Use RTRV commands for monitoring
- Be cautious with DLT and ED commands
- Maintain command logs for auditing

### 4. Performance Tips
- Use specific AIDs instead of ALL when possible
- Batch related commands
- Use appropriate monitoring intervals
- Avoid unnecessary polling

This syntax reference covers the essential TL1 command structure for effective 1603 SM/SMX network element management.