# Bundle Map
- Schemas: data/shared/schemas/*
- Registry/Policies: data/shared/{registry,policies}/*
- Catalogs: data/shared/catalogs/{tl1,dlp,tap}/*
- Alarms: data/shared/alarms/alarm_map.json
- NLP: data/shared/nlp/intents.json
- Tests: tests/vectors/** (raw/expected/notes per case) + index.json
