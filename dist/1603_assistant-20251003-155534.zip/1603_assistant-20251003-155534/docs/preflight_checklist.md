# Preflight Checklist
- Maintenance window? (if required by policy)
- Backup current config (CPY-MEMFTP)
- Verify endpoints free (RTRV-CRS)
- Confirm customer notifications for service-affecting steps
- Ensure rollback commands ready
