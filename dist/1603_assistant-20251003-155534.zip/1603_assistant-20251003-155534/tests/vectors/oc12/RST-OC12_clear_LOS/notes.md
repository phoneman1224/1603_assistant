Auto-remediation candidate per TAP-047 when transient and safe.
