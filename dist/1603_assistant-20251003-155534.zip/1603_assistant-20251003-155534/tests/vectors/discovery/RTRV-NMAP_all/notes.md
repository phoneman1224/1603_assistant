Ring cache should be seeded; post-discovery prompt: Login All | Pick One | Stay on Host.
