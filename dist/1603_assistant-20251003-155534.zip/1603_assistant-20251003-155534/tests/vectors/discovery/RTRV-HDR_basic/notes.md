Simple single-row parse; Connection Panel should show NEID + SWVER.
