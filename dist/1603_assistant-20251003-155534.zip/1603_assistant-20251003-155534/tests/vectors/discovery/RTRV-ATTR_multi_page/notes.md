Multi-page merge; parser must concatenate RTRV blocks until final COMPLD.
