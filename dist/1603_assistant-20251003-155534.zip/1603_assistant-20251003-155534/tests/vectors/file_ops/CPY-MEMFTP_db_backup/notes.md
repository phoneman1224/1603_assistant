Passwords must be masked in logs; attach to device profile backup history.
