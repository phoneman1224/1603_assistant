Preflight must verify endpoints free; if protect requested, orchestrate pass-throughs.
