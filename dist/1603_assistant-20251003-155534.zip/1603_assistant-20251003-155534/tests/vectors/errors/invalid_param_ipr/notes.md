Validator should catch FROM==TO preflight; if not, show 'Failed (preflight missed)'.
