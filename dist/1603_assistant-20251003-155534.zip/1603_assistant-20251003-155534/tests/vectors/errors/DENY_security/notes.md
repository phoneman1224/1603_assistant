Show red banner; do not retry automatically.
