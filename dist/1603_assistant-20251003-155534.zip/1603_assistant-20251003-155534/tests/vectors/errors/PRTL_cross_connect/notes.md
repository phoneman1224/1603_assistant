Offer Verify/Retry; surface partial rows in response analyzer.
