Protect path must be link/node disjoint unless degraded_ok=true.
