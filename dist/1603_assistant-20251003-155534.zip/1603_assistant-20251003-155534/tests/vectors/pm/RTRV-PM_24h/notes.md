Renderer should flag CV above threshold and link to TAP for high BER.
