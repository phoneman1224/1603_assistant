Attach TAP-047 to OC12-LOS and TAP-012 to NEP failure; show Auto-Fix when allowed.
