RMV requires approval (DLP-089). Ensure rollback stack contains RLS-LPBK + RST-T1.
