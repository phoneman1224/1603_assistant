Enforce maintenance window + explicit approval before ACT-SW.
