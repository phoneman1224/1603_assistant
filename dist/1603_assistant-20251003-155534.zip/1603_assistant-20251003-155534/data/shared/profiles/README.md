# Profiles
Store saved connection profiles here. The app will load `*.json` files in this folder.

- Use `example_profile.json` as a template.
- You can keep multiple profiles (one per site/ring).
